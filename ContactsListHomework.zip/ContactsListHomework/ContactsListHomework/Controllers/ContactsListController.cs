﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ContactsListHomework.Controllers
{

    public class Person
    {
        [Required]
        public int id { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }

        [Required]
        public string email { get; set; }

    }
    [ApiController]
    [Route("contactlist")]
    public class ContactsListController : ControllerBase
    {
        private static readonly List<Person> contactsList = new List<Person> { new Person {id = 0, firstName="Adem", lastName="Srndic", email="adem.srndic@hotmail.com"},
        new Person {id = 1, firstName="Armin", lastName="Causevic", email="armin.causevic@hotmail.com"} };

        // Get All Contacts
        [HttpGet]
        public IActionResult GetAllContacts()
        {
            return Ok(contactsList);
        }

        // Get a specific contact
        [HttpGet]
        [Route("findByName")]
        public IActionResult FindPersonByName([FromQuery] string nameFilter)
        {
            if (nameFilter == null)
                return BadRequest("Invalid Name");
            
            IEnumerable<Person> results = from person in contactsList where person.firstName.Equals(nameFilter) ||
                                          person.lastName.Equals(nameFilter) select person;

            if (results.Count() > 0)
                return Ok(results);

            return NotFound("Person not found!");

        }

        [HttpPost]
        public IActionResult AddPerson([FromBody] Person newItem)
        {
            if (newItem == null || newItem.id <= 0 || newItem.email == null)
            {
                return BadRequest("Invalid arguments!");
            }

            if(newItem.id < contactsList.Count)
            {
                return BadRequest("Person already exists!");
            }

            contactsList.Add(newItem);
            return Created("", newItem);

        }

        [[HttpDelete]
        [Route("{index}")]
        public IActionResult DeletePerson(int index)
        {
            if (index < 0)
                BadRequest("Invalid ID");

            foreach (Person person in contactsList)
            { 
            contactsList.RemoveAt(index);
            return NoContent();
            }

            return NotFound("Person not found!");
        }
    }
}
